<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>R-Shopper</title>
    <link href="<?php echo base_url('webassets')?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('webassets')?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url('webassets')?>/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url('webassets')?>/css/price-range.css" rel="stylesheet">
    <link href="<?php echo base_url('webassets')?>/css/animate.css" rel="stylesheet">
	<link href="<?php echo base_url('webassets')?>/css/main.css" rel="stylesheet">
	<link href="<?php echo base_url('webassets')?>/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('webassets')?>/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('webassets')?>/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('webassets')?>/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url('webassets')?>/images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
<?php  
// currency_convert(1,"USD","INR");
function currency_convert($Amount,$currencyfrom,$currencyto)
{
$buffer=file_get_contents('http://finance.yahoo.com/currency-converter');
preg_match_all('/name=(\"|\')conversion-date(\"|\') value=(\"|\')(.*)(\"|\')>/i',$buffer,$match);
$date=preg_replace('/name=(\"|\')conversion-date(\"|\') value=(\"|\')(.*)(\"|\')>/i','$4',$match[0][0]);
unset($buffer);
unset($match);
$buffer=file_get_contents('http://finance.yahoo.com/currency/converter-results/'.$date.'/'.$Amount.'-'.strtolower($currencyfrom).'-to-'.strtolower($currencyto).'.html');
preg_match_all('/<span class=\"converted-result\">(.*)<\/span>/i',$buffer,$match);
$match[0]=preg_replace('/<span class=\"converted-result\">(.*)<\/span>/i','$1',$match[0]);
unset ($buffer);
return $match[0][0];
}

?>
<?php
function currencyConverter($currency_from,$currency_to,$currency_input){

$yql_base_url = "http://query.yahooapis.com/v1/public/yql";
$yql_query = 'select * from yahoo.finance.xchange where pair in ("'.$currency_from.$currency_to.'")';
$yql_query_url = $yql_base_url . "?q=" . urlencode($yql_query);
$yql_query_url .= "&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
$yql_session = curl_init($yql_query_url);
curl_setopt($yql_session, CURLOPT_RETURNTRANSFER,true);
$yqlexec = curl_exec($yql_session);
$yql_json =  json_decode($yqlexec,true);
$currency_output = (float) $currency_input*$yql_json['query']['results']['rate']['Rate'];

return $currency_output;
}
// currencyConverter($currency_from,$currency_to,$currency_input);
$currency_input = 1;
//currency codes : http://en.wikipedia.org/wiki/ISO_4217
$currency_from = "USD";
$currency_to = "INR";
//$currency = currencyConverter($currency_from,$currency_to,$currency_input);

 //echo $currency_input.' '.$currency_from.' = '.$currency.' '.$currency_to;
?>
<script>
	function currency_convertor () {
		
	  var country_id=$("#currency").val();

	  if(country_id=='1'){

	  	var currency=currencyConverter('USD','INR',1);
	  	alert(currency);
	  }else if(country_id=='2'){
	  		var currency=currencyConverter('INR','USD',1);
	  		alert(currency);
	  }

	}
</script>
<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> <?php $contact= $this->session->userdata('user_contact');
								$email= $this->session->userdata('user_email');
									if(!empty($contact)){
										echo $contact;}else if(empty($contact) && !empty($email)){ echo "1800-123456"; }else{ echo '+91-9770543137';
									}?></a></li>
								<li><a href="#"><i class="fa fa-envelope"></i><?php 
								if(!empty($email)){
										echo ' '.$email;}else{ echo ' '.'Blm.ypsilon@gmail.com';
									}?></a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="<?php echo site_url('website');?>"><img src="<?php echo base_url('webassets')?>/images/home/logo.png" alt="" /></a>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">
								<!--<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">-->
									<!--<select class="btn btn-default dropdown-toggle usa" id="currency" onchange="currency_convertor()">
										<option value="1">India</option>
										<option value="2">US</option>
									</select>-->
									<!--<span class="caret"></span>-->
							<!--	</button>
							<!--	<ul class="dropdown-menu">
									<li><a href="#">India</a></li>
									<li><a href="#">Canada</a></li>
									<li><a href="#">USA</a></li>
							</ul>-->
							</div>
							
							<!--<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									Rupees
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="#">Rupees</a></li>
									<li><a href="#">US Dollar</a></li>
									<li><a href="#">Pound</a></li>
								</ul>
							</div>-->
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<?php $user_name= $this->session->userdata('user_name');
								if(!empty($user_name)){ ?>
									<li><a href="#"><i class="fa fa-user"></i> <?php echo $user_name; ?></a></li>
							<?php	} ?>
								
							<li><a href="<?php echo site_url('website/contact_us');?>"><i class="fa fa-phone"></i> Contact</a></li>
									<?php  if($this->session->userdata('user_id')){ ?>
								<li><a href="<?php echo site_url('website/order_list'); ?>"><i class="fa fa-star"></i> My Order</a></li>
								<!--<li><a href="<?php echo site_url('website/checkout');?>"><i class="fa fa-crosshairs"></i> Checkout</a></li>-->
								
								
								<li><a href="<?php echo site_url('website/cart');?>"><i class="fa fa-shopping-cart"></i> Cart<?php if(!empty($value)){?>(<?php echo $value; ?>)<?php }}?>
								<?php  if($this->session->userdata('user_id')){ ?>
									<li><a href="<?php echo site_url('website/logout');?>"><i class="fa fa-lock"></i> Logout</a></li>
						<?php		}else{ ?>
							<li><a href="<?php echo site_url('website/login');?>"><i class="fa fa-lock"></i> Login</a></li>
					<?php	}?>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="<?php echo site_url('website');?>" class="active">Home</a></li>
								<li class="dropdown"><a href="#">Shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="<?php echo site_url('website/shop');?>">Products</a></li>
										<!--<li><a href="<?php echo site_url('website/product_details');?>">Product Details</a></li> -->
										
                                    </ul>
                                </li> 
							<!--	<li class="dropdown"><a href="#">Blog<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="<?php // echo site_url('website/blog');?>">Blog List</a></li>
										<li><a href="<?php //echo site_url('website/blog_single');?>">Blog Single</a></li>
                                    </ul>
                                </li> 
								-->
								
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search" name="serach" id="search" onkeyup="search_product()">
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
<script>
	function search_product(){
		var product_name=$("#search").val();
		$.ajax({
	                    url: '<?php echo site_url('website/search_product'); ?>',
	                    type: "POST",
	                    data: {
	                        'product_name': product_name
	                    },
	                    
	                    
	                    success: function (data) {
	                  
	                    	$("#products").html(data);
	                    
	                    	 }
	                });
	}
</script>