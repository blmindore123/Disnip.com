<section id="form" style="margin-top: 40px"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<?php if($this->session->flashdata('error')){ ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <strong><?php echo $this->session->flashdata('error'); ?></strong>
        </div>
    </div>
</div>
<?php } ?>
<?php if($this->session->flashdata('success')){ ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <strong><?php echo $this->session->flashdata('success'); ?></strong>
        </div>
    </div>
</div>
<?php } ?>
						<form action="<?php echo site_url('website/login')?>" name="form1" method="post">
							
							<input type="email" placeholder="EmailAddress" name="user_email_id" class="form-control input-dark <?php if (form_error('user_email_id')!="") echo "error"; ?>" name="user_email_id" id="user_email_id" autocomplete="off" value="<?php echo set_value('user_email_id'); ?>" onkeypress="remove_class('user_email_id')"/>  <?php echo form_error('user_email_id'); ?>
							<input type="password" placeholder="Password" name="user_pass" value="<?php echo set_value('user_pass'); ?>" autocomplete="off" onkeypress="remove_class('user_pass')" />
                                                
                                                <?php echo form_error('user_pass'); ?>
						<br><span>
								<input type="checkbox" class="checkbox"> 
								Keep me signed in
							</span>
							<button type="submit" class="btn btn-default" name="login" value="Login">Login</button>
							<a onclick="fb_login()"><img src="<?php echo base_url('uploads/invoice_logo/facebook.png') ?>" class="fb_image"></a>
						</form>
					</br>
						   
						     <!--<span class="google"><a class="" href="<?php echo site_url('website/google_login/Google') ?>"><img src="<?php echo base_url('uploads/invoice_logo/google.png') ?>" class="googleimg"></a></span>-->
					</div><!--/login form-->
					
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<?php if($this->session->flashdata('error1')){ ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <strong><?php echo $this->session->flashdata('error1'); ?></strong>
        </div>
    </div>
</div>
<?php } ?>
<?php if($this->session->flashdata('success1')){ ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <strong><?php echo $this->session->flashdata('success1'); ?></strong>
        </div>
    </div>
</div>
<?php } ?>
						<form action="<?php echo site_url('website/signup') ?>" role="form" id="form1" method="post" class="validate">
							<input type="text" placeholder="Name" name="user_name" autocomplete="off" value="<?php echo set_value('user_name'); ?>" onkeypress="remove_class('user_name')"/>  <?php echo form_error('user_name'); ?>
							<input type="email" placeholder="Email Address" name="user_email" autocomplete="off" value="<?php echo set_value('user_email'); ?>" onkeypress="remove_class('user_email')"/>  <?php echo form_error('user_email'); ?>
							<input type="password" placeholder="Password" name="user_password" autocomplete="off" value="<?php echo set_value('user_password'); ?>" onkeypress="remove_class('user_password')"/>  <?php echo form_error('user_password'); ?>
							<input type="number" placeholder="Mobile No" name="user_contact_no" autocomplete="off" value="<?php echo set_value('user_contact_no'); ?>" onkeypress="remove_class('user_contact_no')"/>  <?php echo form_error('user_contact_no'); ?>
							<button type="submit" class="btn btn-default"  name="signup" value="signup">Signup</button>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	      	<input type="submit" class="form-control btn btn-lg orange-btn" name="login" value="Login">
                           <script>
         window.fbAsyncInit = function() {
       FB.init({
            appId      : '594649877357899',
            cookie     : true,  // enable cookies to allow the server to access 
                                // the session
            xfbml      : true,  // parse social plugins on this page
            version    : 'v2.2' // use version 2.2
        });
    };

    // Load the SDK asynchronously
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  
    function fb_login(){
        FB.login(function(response) {
      
            if (response.status === 'connected') {
                FB.api('/me?fields=id,name,email,first_name,last_name', function(response) {
                	$.ajax({
                        'url' :'<?php echo site_url('website/fblogin');?>',
                        'type':'POST',
                        'data':{'fb_response':response},
                        'success' : function(data)
                        { 
                        	 if(data == 1){
                                window.location = "<?php echo site_url('website'); ?>";
                            }
                        }
                    });
                });
            } else if (response.status === 'not_authorized') {
                // The person is logged into Facebook, but not your app.
            } else {
                // The person is not logged into Facebook, so we're not sure if
                // they are logged into this app or not.
            }
        }, {scope: 'public_profile,email'});
    }</script> 
