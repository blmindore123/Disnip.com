<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						
							<?php if(!empty($product)){
							
								$total=0; 
								$service_tex=120;
								$i=0;
								foreach ($product as $value) {
									 ?>
								<tr>
									<td class="cart_product">
										<div class="product-img">	
										<img class="img-responsive" src="<?php echo product_image.'/'.$value[0]->product_image; ?>" alt="" /></div>
									</td>
									<td class="cart_description">
										<h4><a href=""><?php echo $value[0]->product_name;?></a></h4>
									
									</td>
							<td class="cart_price">
								<p><?php echo $value[0]->product_cost;?> Rs</p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<a class="cart_quantity_up" href="<?php echo site_url('website/cart').'/'.$value[0]->product_id.'/'.$cart[$i]->cart_product_qty ?>"> + </a>
									<input class="cart_quantity_input" type="text" name="quantity" value="<?php echo $cart[$i]->cart_product_qty; ?>" autocomplete="off" size="2">
									<a class="cart_quantity_down" href="<?php echo site_url('website/cart').'/'.$value[0]->product_id.'/'.$cart[$i]->cart_product_qty.'/'.'2' ?>"> - </a>
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price">Rs.<?php echo $subtotal=$cart[$i]->cart_product_qty*$value[0]->product_cost;?></p>
							</td>
							<td class="cart_delete">
								<a class="cart_quantity_delete" onClick="if(!confirm('Are you sure, You want delete this Item from cart?')){return false;}" href="<?php echo site_url('website/remove_cart').'/'.$cart[$i]->cart_id;?>"><i class="fa fa-times"></i></a>
								
							</td>
						</tr>
					<?php	
					$i++;
					$total=$total+$subtotal;
							}
							}else{?>
								
<tr>
	<td class="cart_price" colspan="6" align="center">
										<div class="cart_quantity_button">	
									 <img  src="<?php echo base_url('uploads/') ?>/cart-icon.png" alt="..."/>
                    <h4>Oops! Your cart is empty.</h4>
                    <p><a href="<?php echo site_url('website/') ?>" style="width: 200px;color: #428BCA;float: none;display: inline-block">Start shopping</a></p>
                    </div> 
										</div>
									</td>
</tr>								
								
<?php							} ?>
						

						
				
					</tbody>
				</table>
			</div>
		</div>
	</section> <!--/#cart_items-->

	<section id="do_action">
		<div class="container">
			<div class="heading">
				<h3>What would you like to do next?</h3>
				<p>Choose if you have a discount code or reward points you want to use or would like to estimate your delivery cost.</p>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="chose_area">
						<ul class="user_option">
							<li>
								<input type="checkbox">
								<label>Use Coupon Code</label>
							</li>
							<li>
								<input type="checkbox">
								<label>Use Gift Voucher</label>
							</li>
							<li>
								<input type="checkbox">
								<label>Estimate Shipping & Taxes</label>
							</li>
						</ul>
						<ul class="user_info">
							<li class="single_field">
								<label>Country:</label>
								<select>
									<option>United States</option>
									<option>Bangladesh</option>
									<option>UK</option>
									<option>India</option>
									<option>Pakistan</option>
									<option>Ucrane</option>
									<option>Canada</option>
									<option>Dubai</option>
								</select>
								
							</li>
							<li class="single_field">
								<label>Region / State:</label>
								<select>
									<option>Select</option>
									<option>Dhaka</option>
									<option>London</option>
									<option>Dillih</option>
									<option>Lahore</option>
									<option>Alaska</option>
									<option>Canada</option>
									<option>Dubai</option>
								</select>
							
							</li>
							<li class="single_field zip-field">
								<label>Zip Code:</label>
								<input type="text">
							</li>
						</ul>
						<a class="btn btn-default update" href="">Get Quotes</a>
						<a class="btn btn-default check_out" href="">Continue</a>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="total_area">
						<ul>
							<li>Cart Sub Total <span>Rs.<?php if(!empty($product)){ echo $total; }else{ echo '00';}?></span></li>
							
							<li>Shipping Cost <span>Free</span></li>
							<li>Total <span> Rs.<?php if(!empty($product)){ echo $total; }else{ echo '00';}?> </span></li>
						</ul>
							<a class="btn btn-default update" href="<?php echo site_url('website/checkout') ?>">Check out</a>
						
					</div>
				</div>
			</div>
		</div>
	</section><!--/#do_action-->