
<div class="panel panel-default">
	
	<div class="panel-heading">
		<div class="panel-title">
				Shopper Management
		</div>
		
	</div>
	<div class="panel-body">
			<div class="panel-body">
        <div class="row">
            <div class="col-sm-3">
                <div class="xe-widget xe-counter" data-count=".num" data-from="0" data-to="<?php echo $user_count; ?>" data-suffix="" data-duration="2">
                    <div class="xe-icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <div class="xe-label">
                        <strong class="num">10,500</strong>
                        <span>User</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="xe-widget xe-counter" data-count=".num" data-from="0" data-to="<?php echo $category; ?>" data-suffix="" data-duration="2">
                    <div class="xe-icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <div class="xe-label">
                        <strong class="num">10,500</strong>
                        <span>Category </span>
                    </div>
                </div>
            </div>
           <div class="col-sm-3">
                <div class="xe-widget xe-counter" data-count=".num" data-from="0" data-to="<?php echo $product; ?>" data-suffix="" data-duration="2">
                    <div class="xe-icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <div class="xe-label">
                        <strong class="num">10,500</strong>
                        <span>Products </span>
                    </div>
                </div>
            </div>
         
           </div>
        </div>
	</div>
</div>


