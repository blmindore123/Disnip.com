<!--<div id="all_category_attributes" class="form-group">-->
<?php if(!empty($attributes_detail)){ ?>
<label class="control-label">Attributes</label>
                <?php if(!empty($attributes_detail)){ foreach ($attributes_detail as $value) { ?>
               <div class="row">
                    <div class="col-md-5">
                        <input type="text" class="form-control" placeholder="Attribute Name" value="<?php echo $value->attribute_name; ?>" readonly="true"/>
                    </div>
                    <div class="col-md-5">
                        <input type="hidden" name="attribute_id[]" value="<?php echo $value->attribute_id; ?>" readonly="true"/>
                        <select class="form-control" name="attribute_value_id[]" multiple="multiple">
                                <option value="">Select</option>
                                <?php //$explode=explode(',', $value->attribute_value); ?>
                                <?php foreach ($attribute_values as $val) {
                                    if($val ->attribute_id==$value->attribute_id){
                                    ?>
                                
                                <option value="<?php if (!empty($val -> attribute_value_id)) {
                                    
                                    echo $val ->attribute_value_id;    
                                    
                                     
                                }?>" <?php if (!empty($val -> attribute_value_id) && !empty($product_details[0] -> attribute_value_id)) {
                        $explode=explode(',', $product_details[0] -> attribute_value_id);
                        $test=in_array($val -> attribute_value_id, $explode);
        if ($val -> attribute_value_id == $test) {echo "selected='selected'";
        }}
        ?>>
        <?php echo $val->attribute_value_name; ?></option><?php }} ?>
                                
                            </select>
                    </div>
                   
               </div>
                <?php }} ?>
                <div class="clearfix"></div>
                <?php } ?>
<!--                </div>-->