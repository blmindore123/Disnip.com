
<main id="main" class="site-content">
             


            <section class="mt-80">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="section-title style9 text-center text-uppercase">
                                <h4 class="title-ls relative inline">Product Showcase</h4>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <aside class="col-xs-12 col-md-3 widget-area mb-50">
                            <section class="widget type-2 z-depth-1">
                                <h5 class="widget-title text-uppercase mb-25">Product Filter By</h5>
                                <div class="custom-chekbox-2 icon-check mb-15">
                                    <input id="latestpro" type="checkbox">
                                    <label for="latestpro" class="fw300">Latest Product</label>
                                </div>
                                <div class="custom-chekbox-2 icon-check mb-15">
                                    <input id="ltoh" type="checkbox">
                                    <label for="ltoh" class="fw300">Low to High</label>
                                </div>
                                <div class="custom-chekbox-2 icon-check mb-15">
                                    <input id="htol" type="checkbox">
                                    <label for="htol" class="fw300">High to Low</label>
                                </div>
                            </section>
                            <section class="widget type-2 z-depth-1">
                                <h5 class="widget-title text-uppercase mb-25">Filter by Price</h5>
                                <div class="price-label flex flex-middle space-between">
                                    <span>50</span>
                                    <span>500</span>
                                </div>
                                <div class="price-filter"></div>
                            </section>
                             
                            <section class="widget type-2 z-depth-1 latestproductonshop-sec">
                                <h5 class="widget-title text-uppercase mb-25">Latest Items</h5>
                                <ul>
                                    <?php if(!empty($product)) {
                                      
                                   // for($i=0;$i<3;$i++){
                                      // forea
                                      $i=0;
                                       foreach ($product as $value){
                                           if($i<3){
                                    ?>
                                    <li class="flex mb-10">
                                        <figure class="thumb">
                                            <img src="<?php echo product_image.'/'.$product[$i]->product_image ?>" class="img-responsive" alt="">
                                        </figure>
                                        <div class="text ml-15">
                                            <a href="#" class="title title-link"><?php echo $product[$i]->product_name; ?></a><br>
                                            <span class="h6 fw400">&#8377; <?php echo $product[$i]->product_cost; ?></span>
                                        </div>
                                    </li>
                                   <?php
                                  $i++; } } } ?>
                                </ul>
                            </section>
                        </aside> <!-- /.col- -->
                        <div class="col-xs-12 col-md-9">
                            

<div class="row multiples_product_section-shop">  <?php foreach ($product as $value) { ?>
   <div class="col-xs-12 col-sm-6 col-md-4 mb-30">
      <div class="product type-7 z-depth-1 white-bg text-center">
          <figure class="thumb relative">
            <img src="<?php echo product_image.'/'.$value->product_image ?>" class="img-responsive" alt="">
            
            <ul class="product-actions">
               <li><a href="#" class="add-to-cart"onclick="addCart('<?php echo $value->product_id; ?>','<?php echo $value->product_name; ?>','<?php echo product_image.'/'.$value->product_image; ?>','<?php echo ($value->product_cost)-($value->product_cost/100*$value->product_discount_per); ?>','<?php echo '1'; ?>');"></a></li>
         
               <li><a href="<?php echo site_url(); ?>/website/product_detail/<?php echo base64_encode($value->product_id); ?>" class="quick-view"><i class="fa fa-expand"></i></a></li>
            </ul>
         </figure>
         <div class="title prod-titles">
            <h5 class=" title-ls"><a href="<?php echo site_url(); ?>/website/product_detail/<?php echo base64_encode($value->product_id); ?>" class="title-link"><?php echo $value->product_name; ?></a></h5>
            
         </div>
         
         <h5 class="price f700">&#8377; <?php echo $value->product_cost; ?></h5>
         <span class="percentageoff"><?php echo $value->product_discount_per ?>% off</span>
      </div>
      <!-- /.product type-7 -->
</div><?php } ?>
   <!-- /.col- -->
    
   <!-- /.col- -->
</div>

                            <h1>&nbsp;</h1>
                          <!--  <nav class="pagination-2 pull-right">
                                <ul class="inline-flex flex-middle">
                                    <li><a href="#">PREV</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#" class="active">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">NEXT</a></li>
                                </ul>
                            </nav>-->
                        </div> <!-- end .col-md-9 -->
                    </div> <!-- /.row -->
                </div> <!-- /.contianer -->

            </section>
            <!-- /.section-full -->
        </main> <!--  .site-content  -->



        
        <!--
        JavaScripts
        ========================== -->
        <script src="<?php echo base_url('webassets/js/scripts.minified.js');?>"></script>
        <script src="<?php echo base_url('webassets/js/main.js');?>"></script>        <script>
            var price_filter = document.querySelector(".price-filter");
            noUiSlider.create(price_filter, {
                start: [100, 400],
                connect: true,
                step: 1,
                range: {
                    'min': 0,
                    'max': 500
                },
                format: wNumb({
                    decimals: 0
                })
            });
        </script>
    </body>

<!-- Mirrored from codepixar.com/matex/matex/shop-4c-left-sidebar.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Jul 2017 13:11:00 GMT -->
</html>