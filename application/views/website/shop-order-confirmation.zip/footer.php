<!-- include file -->
<footer class="site-footer">

    <!-- footer-widget-3 -->

    <div class="secondery-footer dark">
        <div class="container">
            <div class="inner-footer">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8">
                        <p>Copyright 2017 Dismip | All Rights Reserved </p>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <ul class="social-links social-1 text-right">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <a href="javascript:void(0)" id="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>        <!-- include file -->


<!--
JavaScripts
========================== -->
<script src="<?php echo base_url('webassets/js/scripts.minified.js'); ?>"></script>
<script src="<?php echo base_url('webassets/js/main.js'); ?>"></script>    </body>
<script>
   var cart = [];
    if (localStorage.getItem('items') !== null) {
        var cart = JSON.parse(localStorage.getItem("items"));
    } else {
        var cart = [];
    }
    if (localStorage.getItem('ttl') !== null) {
        var ttl = parseInt(localStorage.getItem("ttl"));
    } else {
        var ttl = 0;
    }
    if (localStorage.getItem('count') !== null) {
        var count = parseInt(localStorage.getItem("count"));
    } else {
        var count = 0;
    }
    
     if (localStorage.getItem('itmqty') !== null) {
        var itmqty = parseInt(localStorage.getItem("itmqty"));
    } else {
        var itmqty = 0;
    }
    function addCart(id, name, img, price, qty) {
ttl = parseInt(price*qty) + parseInt(ttl);
        var myArray = cart;

      var objIndex = myArray.findIndex((obj => obj.item_id == id));
    
if(objIndex>=0){
//Console object.
console.log("Before update: ", myArray[objIndex]);

//Update object's name property.
myArray[objIndex].qty = parseInt(myArray[objIndex].qty)+parseInt(qty);

//Console object again.
console.log("After update: ", myArray[objIndex]);
 localStorage.setItem('items', JSON.stringify(myArray));
location.reload();
        }else{

       
        
        $('#itemslist').append('<div class="cart-product relative flex flex-middle" id="'+cart.length+'"><figure class="thumb mr-20"><a href="#"><img width="100" src="' + img + '" alt=""></a></figure><div class="desc"><h6 class="roboto mb-10"><a href="#" class="title-link">' + name + '</a></h6><span class="price title-color fw500">Rs ' + price + ' x ' + qty + '</span> </div><a href="javascript:;" class="remove-product transition" onclick="removeByValue('+cart.length+');"></a></div>');
        $('#ttlprc').html('Rs ' + ttl);
        $('#cont').html(cart.length + 1);
       localStorage.setItem('ttl', ttl);
             localStorage.setItem('count', cart.length + 1);
        var items = {
            id: cart.length,
            item_id: id,
            name: name,
            img: img,
            price: price,
            qty: qty
        };

        cart.push(items);

        localStorage.setItem('items', JSON.stringify(cart));
        // $('#displaynames').html(localStorage.getItem('items'));
      //  alert(localStorage.getItem('items'));
    }}
$(document).ready(function() {
    ttl=0;
 $('#ttlprc').html('Rs ' + ttl);
        $('#cont').html(count);
        for(var i=0;i<cart.length;i++){
               ttl = parseInt(cart[i].price*cart[i].qty ) + parseInt(ttl);
    $('#itemslist').append('<div class="cart-product relative flex flex-middle" id="'+i+'" ><figure class="thumb mr-20"><a href="#"><img width="100" src="' + cart[i].img + '" alt=""></a></figure><div class="desc"><h6 class="roboto mb-10"><a href="#" class="title-link">' + cart[i].name + '</a></h6><span class="price title-color fw500">Rs ' + cart[i].price + ' x ' + cart[i].qty + '</span> </div><a href="javascript:;" class="remove-product transition"  onclick="removeByValue('+i+');"></a></div>'); 
    $('#ttlprc').html('Rs ' + ttl);
     localStorage.setItem('ttl', ttl);
    }
        
});

	
function removeByValue(id) {
       // alert(mylist);
        var arr = cart;
        
          localStorage.setItem('count', parseInt((localStorage.getItem("count") - 1)));
                arr.splice(id, 1);
                cart=arr;
                localStorage.setItem('items', JSON.stringify(cart).replace(/\\/g, ""));
                $('#' + id).remove();
                $('#1' + id).remove();
                location.reload();
            

    }
    
    function changeByValue(id) {
  var val= $('#qtyp'+id).val();
        var myArray = cart;

      var objIndex = myArray.findIndex((obj => obj.id == id));

//Console object.
console.log("Before update: ", myArray[objIndex]);

//Update object's name property.
myArray[objIndex].qty = val;
  localStorage.setItem('items', JSON.stringify(myArray));
//Console object again.
console.log("After update: ", myArray[objIndex]);
location.reload();
    }
    
    //Find index of specific object using findIndex methode.    


</script>

<!-- Mirrored from codepixar.com/matex/matex/shop.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Jul 2017 12:42:10 GMT -->
</html>