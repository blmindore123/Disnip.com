
        <main id="main" class="site-content">
             
            <!-- /.page-header -->
            <section class="mb-40 mt-40">
                <div class="container">
                  <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
                            <div class="section-title style4 text-center">
                                <h2 class="text-uppercase">Our Story</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor.</p>
                                <div class="sep"></div>
                            </div>
                        </div>
                    </div> <!-- end .row -->

                    <div class="row">
                 
                        <div class="col-md-12 col-lg-12">
                            <div class="feature-5">
                                <h3>WHO WE ARE</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
                            </div>
                            <div class="feature-5">
                                <h3>OUR MISSION</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
                            </div>
                            <div class="feature-5">
                                <h3>WAY OF WORKING</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
                            </div>
                        </div> <!-- /.col- -->
                    </div>  <!-- end .row -->  
                </div> <!-- /.container -->
            </section>
            <section class="section-full relative gray-bg-3 img-text-section">
                <div class="bg-img left" style="background-image: url(http://onewaycreation.com/Disnip.com/webassets/img/product/novel.jpg);  "></div>
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-offset-7 col-md-5">
                            <div class="parallax-block-2 section-title no-margin style4">
                                <h2 class="text-uppercase title-ls">Disnip Exclusive Offsers</h2>
                                <div class="sep left"></div>
                                <p class="mt-50">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                                <a href="#!" class="waves-effect btn-large btn-white mt-35 text-uppercase">View Offers List</a>
                                <div class="right-bg"></div>
                            </div>
                        </div>
                    </div>        
                </div>
            </section>

                <!-- parallax section -->
            <section class="relative section-full primary-bg">
                <div class="container relative">
                    <div class="row">
                        <div class="col-lg-offset-1 col-lg-4">
                            <div class="tm-title">
                                <h2 class="fw300">Customer feedback About Disnip</h2>
                                <p class="fw300">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-lg-offset-1 col-lg-5">
                            <div class="tm-carousel-3 bullet-two">
                                <div class="tm-item style2">
                                    <blockquote>
                                        <i class="fa fa-quote-left"></i>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici ng elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. laboris nisi ut aliquip ex ea commodo consequat. </p>
                                    </blockquote>
                                    <div class="author-info">
                                        <span class="name">george milan</span>
                                        <span>CEO <a href="#">Lorem Ipsum</a></span>
                                    </div>
                                </div>
                                <div class="tm-item style2">
                                    <blockquote>
                                        <i class="fa fa-quote-left"></i>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici ng elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. laboris nisi ut aliquip ex ea commodo consequat. </p>
                                    </blockquote>
                                    <div class="author-info">
                                        <span class="name">george milan</span>
                                        <span>CEO <a href="#">digital map</a></span>
                                    </div>
                                </div>
                                <div class="tm-item style2">
                                    <blockquote>
                                        <i class="fa fa-quote-left"></i>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisici ng elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. laboris nisi ut aliquip ex ea commodo consequat. </p>
                                    </blockquote>
                                    <div class="author-info">
                                        <span class="name">george milan</span>
                                        <span>CEO <a href="#">digital map</a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


 

        </main> <!--  .site-content  -->

        <!-- include file -->
                         <div class="secondery-footer dark">
                            <div class="container">
                                <div class="inner-footer">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6 col-md-8">
                                            <p>Copyright 2017 Dismip | All Rights Reserved </p>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-4">
                                            <ul class="social-links social-1 text-right">
                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                                 
                                                 
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="javascript:void(0)" id="go-top">
                                <i class="fa fa-angle-up"></i>
                            </a>
                        </div>
                    </footer>        <!-- include file -->

        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/scripts.minified.js"></script>
        <script src="js/main.js"></script>    </body>
 
</html>