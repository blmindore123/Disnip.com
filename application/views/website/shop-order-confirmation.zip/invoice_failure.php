<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];

  $this->session->set_userdata("pstatus", 'Failed');
  $this->session->set_userdata("txnid", $txnid);
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$salt="GQs7yium";

  $this->session->set_flashdata("msgSuccess", "Transection failed");
                    redirect('website/order_confirmation');