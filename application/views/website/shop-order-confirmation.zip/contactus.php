
        <main id="main" class="site-content">
             <section id="contact" class="section-full gray-bg-3" style="background-image: url(http://onewaycreation.com/Disnip.com/assets/images/bglogin.jpg);  background-size: 100% 100%;">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-offset-2 col-md-8 getin-touch-box">
                            <div class="section-title style3 text-center">
                                <h2 class="text-uppercase" style="color: #fff;">Get in <b>Touch</b></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                            </div>
                        </div>
                    </div> <!-- end .row -->
                </div>  <!-- end .container -->
                <div class="container">
                    <div class="row bottom-half mobile-info-box">
                        <div class="col-sm-4 bottom-margin">
                            <div class="contact-block dark text-center">
                                <h4 class="text-uppercase title-ls mb-30">Cell number</h4>
                                <p>Phone: +123 4567 890 <br>Phone: +001 2345 678</p>
                            </div>
                        </div>
                        <div class="col-sm-4 bottom-margin">
                            <div class="contact-block dark text-center">
                                <h4 class="text-uppercase title-ls mb-30">Location</h4>
                                <p>169 Old street road, new town <br> ny 36963 usa</p>
                            </div>
                        </div>
                        <div class="col-sm-4 bottom-margin">
                            <div class="contact-block dark text-center">
                                <h4 class="text-uppercase title-ls mb-30">Email support</h4>
                                <p>
                                    <a href="mailto:info@yourdomain.com" class="text-link">info@disnip.com</a> <br>
                                    <a href="mailto:support@yourdomain.com" class="text-link">support@disnip.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- end .row -->

                    <form id="contact-form" class="row contact-form contact-form-box" method="post" novalidate="novalidate">
                        <div class="col-sm-6">
                            <div class="input-field">
                                <input id="name" name="name" class="ml-input" type="text">
                                <label for="name">Name</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <input id="email" name="email" class="ml-input" type="email">
                                <label for="email">Email</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <input id="phoneNumber" name="phoneNumber" class="ml-input" type="text">
                                <label for="phoneNumber">Phone Number</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <input id="subject" name="subject" class="ml-input" type="text">
                                <label for="subject">Subject</label>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="input-field">
                                <textarea id="message" name="message" class="materialize-textarea"></textarea>
                                <label for="message">Message</label>
                            </div>
                        </div>
                        <div class="col-sm-3 col-md-offset-4 col-md-4 text-center">
                            <div class="">
                                <button class="waves-effect btn-large text-uppercase" type="submit">Submit</button>
                            </div>
                            <div class="message-actions">
                                <div class="msg-success">Your message was sent successfully</div>
                                <div class="msg-error">Something went wrong, please try again later.</div>
                            </div>
                        </div>
                    </form>
                    <!-- end .row -->
                </div>
            </section>

        </main> <!--  .site-content  -->

 