             
            <!-- /.page-header -->
            <section class="section-full">
                <div class="container">
                    <ul class="shop-order-progress flex flex-center fw300 mb-50 fz-13">
                        <li><a href="<?php echo site_url(); ?>/website/cart">Order</a></li>    
                        <li><a href="<?php echo site_url(); ?>/website/shipping">Shipping</a></li>    
                        <li><a href="#">Payment</a></li>    
                        <li class="active"><a href="#">Confirmation</a></li>
                    </ul> <!-- end .order-progress -->

                    <div class="row">
                        <div class="col-xs-12">
                            <div class="purchase-confirmation-title mb-30">
                                <h4 class="mb-20 no-ls">Billing Details</h4>
                                <p class="text-success">Thank you! Your order has been received.</p>
                            </div>
                            <!-- /.purchase-confirmation-title -->
                        </div>
                        <div class="col-xs-12 col-sm-8 col-md-9 col-lg-8">
                            <ul class="woocommerce-thankyou-order-details roboto-slab fw300 flex">
                                <li class="order text-color ">Order Number: <span class="title-color roboto fw500 block">#<?php echo $this->session->userdata("engguserid"); ?></span> </li>
                                <li class="date text-color ">Date: <span class="title-color roboto fw500 block"><?php date('d-m-Y')?></span></li>
                                <li class="total text-color ">Total:<span class="price title-color roboto fw500 block" id="ttmt"></span></li>
                                <li class="method text-color ">Payment Method: <span class="title-color roboto fw500 block">Check Payments</span></li>
                            </ul>
                            <!-- /.woocommerce-thankyou-order-details -->
                            <p class="fw300 mt-20">Make your payment directly into our bank account. Pleae use your Order ID as the payment reference. Your order wont be shipped until the funds have cleared in out account</p>

                            <div class="order-details mt-80">
                                <h4 class="fw-700 mb-25">Your Order</h4>
                                <div class="table-responsive">
                                    <table class="table-1 table-cart w100">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody id="coninfo">
                                           
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th scope="row" colspan="3">Subtotal:</th>
                                                <td class="title-color fw700"><span class="price" id="st">$450.00</span></td>
                                            </tr>
                                            <tr>
                                                <th scope="row" colspan="3">Shipping and Handling</th>
                                                <td class="title-color fw700" id="sp">Free</td>
                                            </tr>
                                            <tr>
                                                <th scope="row" colspan="3">Total:</th>
                                                <td class="title-color fw700" id="tl"><span class="price">$450.00</span></td>
                                            </tr>
                                        </tfoot>
                                    </table> <!-- /.table-1 -->
                                </div> <!-- /.table-responsive -->
                            </div>
                        </div> <!-- /.col -->
                        <div class="col-xs-12 col-sm-4 col-md-3 col-lg-offset-1 col-lg-3">
                            <aside class="widget-area">
                                <section class="widget">
                                    <h4 class="widget-title mb-15">Customer Detail</h4>
                                    <p><span class="block fw300">Email</span> <?php echo $address[0]->user_email;?></p>
                                    <p><span class="block fw300">Phone number</span> <?php echo $address[0]->user_mobile_no;?></p>
                                </section>
                                <section class="widget">
                                    <h4 class="widget-title mb-15">Billing Address</h4>
                                    <div class="textwidget fw300">
                                     <?php echo $address[0]->address1.' '.$address[0]->address2.' '.$address[0]->user_pincode.' '.$address[0]->user_city; ?>
                                    </div>
                                </section>
                                <section class="widget">
                                    <h4 class="widget-title mb-15">Shipping Address</h4>
                                    <div class="textwidget fw300">
                                        N/A <br> <br> <br>
                                        <a href="#" class="btn btn-white default-shadow text-uppercase"><i class="fa fa-print mr-5"></i>Print Now</a>
                                    </div>
                                </section>
                            </aside>
                        </div> <!-- /.col -->
                    </div>
                </div> <!-- /.container -->
            </section>
            <!-- //.section-full -->
     <script>
          $(document).ready(function() {
var subt=0;
var ship=0;
var quanty1=0;
var ttlcharges=0;
        for(var i=0;i<cart.length;i++){
$('#spinfo').append(' <tr> <td><h5 class="fw300"><a href="#" class="title-link">'+cart[i].name+'</a></h5></td> <td><span class="price fw300">Rs '+cart[i].price+'</span></td><td>'+cart[i].qty+'</td> <td><span class="price fw300">Rs '+(cart[i].price*cart[i].qty)+'</span></td></tr>'); 
subt=subt+(cart[i].price*cart[i].qty);
  quanty1=parseInt(quanty1)+parseInt(cart[i].qty);
  //alert(quanty1);
    }
    ship=(quanty1*10)+10;
  
   ttlcharges=subt+ship;
  $('#st').html('Rs '+subt);
  $('#sp').html('Rs '+ship);
  $('#tl').html('Rs '+ttlcharges);

   localStorage.clear();
});
           </script>