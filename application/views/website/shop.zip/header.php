<!DOCTYPE html>
<html lang="zxx" class="no-js">
 <meta http-equiv="content-type" content="text/html;charset=UTF-8" /> 
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">

        <!-- Site Title -->
        <title>Dismip</title>
        
        <!--
        CSS
        ============================================= -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,900italic,900,700italic,700,500italic,500,400italic,300italic,300,100italic,100|Poppins:300,400,700">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700|Raleway:300,400,500">
        <link rel="stylesheet" href="../../../maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

        <link rel="stylesheet" href="<?php echo base_url('webassets/css/style.minified.css');?>">
        <link rel="stylesheet" href="<?php echo base_url('webassets/css/main.css');?>">
        <link rel="stylesheet" href="../../../www.codepixar.com/matex/matex/css/style.html">
        
        <script src="<?php echo base_url('webassets/js/vendor/jquery-2.2.4.min.js');?>"></script>
    </head>
    
    <body>
        
                <header id="header" class="site-header header-shop static sticky-js">
            <div class="container">
                <div class="primary-nav-inner relative flex">
                    <a href="<?php echo site_url(); ?>" class="site-logo flex-cell flex-middle" >
                        <!-- <img src="img/logo.png" alt="Materialist"> -->Disnip
                    </a>
                    <!-- end .site-logo -->
                
                    <nav class="primary-nav menu-dark">
                        <ul class="menu-list nav-hover-1 sf-menu clear list-none">
                            <li class="has-dropdown megamenu">
                              <a href="<?php echo site_url('website'); ?>">Home</a>
                            </li>
                            <!-- <li class="has-dropdown megamenu">-->
                            <!--    <a href="<?php echo site_url('website/shop'); ?>">Shop</a>-->
                            <!--</li>-->
							<li class="has-dropdown megamenu">
								<a href="">About Us</a>
							</li>
							<li class="has-dropdown megamenu">
								<a href="<?php echo site_url('website/contactus'); ?>">Contact Us</a>
							</li>
							<li class="booksondemand">
								<a href="<?php echo site_url('website/booksondemand'); ?>">Books on Demand</a>
							</li>
                            <?php if(empty(SESSIONKEY)){ ?>
							<li class="has-dropdown megamenu">
								<a href="<?php echo site_url('website/login'); ?>">Login / Sign Up</a>
                                                       </li><?php }else{ ?>
							 <li class="has-dropdown megamenu">
								<a href="<?php echo site_url('website/logout'); ?>">Logout</a>
                                                       </li><?php } ?>
                            

                       </ul>
                    </nav>
                    <!-- end .primary-nav -->

                    <div class="header-action-btns clear">
                        <div class="top-search transition">
                            <a href="#" class="top-search-trigger absolute-center"></a>
                        </div>
                        <!-- end .top-search -->
                        <div class="top-cart transition">
                            <a href="#" class="top-cart-trigger absolute-center">
                                <span class="count-badge" id="cont">0</span>
                            </a>
                            <div class="header-cart-2 z-depth-1" >
                                <h6 class="cart-title text-color text-uppercase roboto text-center mb-30" >Shopping Cart</h6>
                           <div id="itemslist">  </div>   
                            <div class="product-total row no-gutter text-center fw500 title-color text-uppercase">
                                    <span class="col-xs-6">Total</span>
                                    <span class="col-xs-6" id="ttlprc">Rs 0</span>
                                    <input type="hidden" id="ttl" value="0">
                                </div>
                                <div class="actions text-center">
                                    <span><a href="<?php echo site_url(); ?>/website/cart" class="view-cart title-link text-uppercase">View Cart <i class="fa fa-angle-right"></i></a></span>
                                    <span><a href="<?php echo site_url(); ?>/website/cart" class="btn waves-effect waves-light btn-light-dark">Process to Checkout</a></span>
                                </div>
                            </div>
                        </div>
                        <!-- end .top-cart -->
                    </div>

                    <button class="nav-hamburger dark visible-xs visible-sm">
                        <span>toggle menu</span>
                    </button> <!-- /.nav-hamburger -->
                </div>
            </div> <!-- /.container -->
        </header>
        <!-- /.magazine-header -->
        <div class="search-wrapper">
            <a href="#" class="close-search"><i class="material-icons">close</i></a>
            <form action="#" class="search-popup">
                <div class="input-field">
                    <input type="search" id="search" autocomplete="off">
                    <label for="search">Search here...</label>
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>