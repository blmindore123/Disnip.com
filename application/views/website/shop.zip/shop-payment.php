
 
            <!-- /.page-header -->
            <section class="section top-full">
                <div class="container">
                    <ul class="shop-order-progress flex flex-center fw300 mb-50 fz-13">
                        <li><a href="<?php echo site_url(); ?>/website/cart">Order</a></li>    
                        <li><a href="<?php echo site_url(); ?>/website/shipping">Shipping</a></li>    
                        <li class="active"><a href="#">Payment</a></li>    
                        <li><a href="<?php echo site_url(); ?>/website/order_confirmation">Confirmation</a></li>
                    </ul> <!-- end .order-progress -->

                    <ul class="payment-type flex flex-center disable-flex-xs roboto-slab fw300">
                         
                        <li class="" ><a href="" onclick="payumoney();"><span class="block h3 f700 title-color text-uppercase">Card </span>Debit Cards</a></li>
                         
                        <li class=""><a href=""><span class="block h3 f700 title-color text-uppercase">Cash </span>Cash On Delivery</a></li>
                    </ul>
                </div>
            </section>

            <section class="section bottom-full gray-bg-3">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
                            <div class="card-information">
                                <form class="row" action="#">
                                    <div class="col-xs-12">
                                        <div class="input-field ml-selectize">
                                            <select name="card_type" id="card_type" class="selectize">
                                                <option value="master-card" selected="selected">Master Card</option>
                                                <option value="visa-card">Visa</option>
                                                <option value="american-express">American Express</option>
                                                <option value="paypal">Paypal</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-field">
                                            <input id="card_number" type="text" class="ml-input margin-b-0">
                                            <label for="card_number">Card Number</label>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6">
                                        <div class="input-field">
                                            <input id="expiration_date" type="text" class="ml-input margin-b-0">
                                            <label for="expiration_date">Expiration Date</label>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6">
                                        <div class="input-field">
                                            <input id="card_cvv" type="text" class="ml-input margin-b-0">
                                            <label for="card_cvv">Card CVV</label>
                                        </div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="input-field">
                                            <input id="card_holder_name" type="text" class="ml-input margin-b-0">
                                            <label for="card_holder_name">Card Holder Name</label>
                                        </div>
                                    </div>
                                </form> <!-- /.row -->

                                <div class="cart-actions mt-60 text-right">
                                    <a href="shop-shipping.html" class="waves-effect btn-large btn-white text-uppercase">Back to Shipping</a>
                                    <a href="shop-order-confirmation.html" class="waves-effect btn-large waves-light btn-light-dark text-uppercase ml-20">Place Order</a>
                                </div>
                            </div> <!-- /.card-information -->
                        </div>
                    </div>
                </div> <!-- /.container -->
            </section>
            <!-- //.section-full -->
<?php

$MERCHANT_KEY = "W8Sifn";
$SALT = "xmOBIXfT";
// End point - change to https://secure.payu.in for LIVE mode
$PAYU_BASE_URL = "https://test.payu.in";
$action = '';
$posted = array();
$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
$posted['txnid'] = $txnid;
$posted['key'] = $MERCHANT_KEY;
$posted['surl'] = site_url('website/success_payumoney');
$posted['furl'] = site_url('website/cancel_payumoney');
$posted['productinfo'] = 'R-Shopper Products';
$posted['service_provider'] = 'payu_paisa';
$posted['phone'] = $address[0]->user_mobile_no;;
$posted['firstname'] = $address[0]->user_name;
$posted['amount'] = base64_decode($this->uri->segment(3));
$posted['email'] = $address[0]->user_email;;
$posted['address1'] = $this->session->userdata('user_id');;

if(!empty($_GET)) {
    //print_r($_POST);
  foreach($_GET as $key => $value) {    
    $posted[$key] = $value; 
  }
}
// $posted = array();
// if(!empty($_POST)) {
    // //print_r($_POST);
  // foreach($_POST as $key => $value) {    
    // $posted[$key] = $value; 
// }
// }
$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';

// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
		  || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
	$hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';	
	foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
  <script>
  
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {

      payuForm.submit();
    }
  </script>
<?php $product_info= "Book Shop"; 
 if(!empty($address)){ $mobile=$address[0]->user_mobile_no; 
 $name= $address[0]->user_name;
 $email=$address[0]->user_email;
 $success_payu=site_url('website/success_payumoney');
  $cancel_payu=site_url('website/cancel_payumoney'); 
  $user_id=$this->session->userdata('user_id');
  
   }
?>
  <input type="test" value="payumoney" id="payumoney">
<form action="<?php echo $action; ?>" method="post" name="payuForm">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <input type="hidden" name="amount" id="amount" value="<?php echo (empty($posted['amount'])) ? "''" : $posted['amount'] ?>" />
      <input type="hidden" name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? "'".$user_id."'" : $posted['firstname']; ?>" />
      <input type="hidden" name="email" id="email" value="<?php echo (empty($posted['email'])) ? "'".$email."'" : $posted['email']; ?>" />
      <input type="hidden" name="phone" value="<?php echo (empty($posted['phone'])) ? "'".$mobile."'" : $posted['phone']; ?>" />
      <input type="hidden" name="productinfo" value="<?php echo (empty($posted['productinfo'])) ? "'".$product_info."'" : $posted['productinfo'] ?>" >
      <input type="hidden" name="surl" value="<?php echo (empty($posted['surl'])) ? "'".$success_payu."'" : $posted['surl'] ?>" size="64" />
      <input type="hidden" name="furl" value="<?php echo (empty($posted['furl'])) ? "'".$cancel_payu."'" : $posted['furl'] ?>" size="64" />
      <input type="hidden" name="address1" value="<?php echo (empty($posted['address1'])) ? "'".$user_id."'" : $posted['address1'] ?>" size="64" />
      <input type="hidden" name="service_provider" value="payu_paisa" size="64" /></td>
       <?php if(!$hash) { ?>
       <input type="submit" value="Submit" name="submit" style="display: none"/>
      <?php } ?>
    </form>

    
	<script>
	
	function cashondelivery(){
		var cod= $('#cod').val();
	
				$.ajax({
	                    url: '<?php echo site_url('website/get_order'); ?>',
	                    type: "POST",
	                    data: {
	                        'cod': cod
	                    },
	                    
	                    
	                    success: function (data) {
	                    	if(data=='2'){
	                    		alert("Delivery Address is Empty");
	                    		$('#cod').attr('checked', false);
	                    	}else if(data=='1'){
	                    		$('#cod').attr('checked', false);
	                    		location.reload(); 
	                    	}else if(data=='3'){
	                    		alert("Your Cart is Empty, Please Continue Shopping");
	                    		$('#cod').attr('checked', false);
	                    		
	                    	}
	                    	 }
	                });
	}
	function payumoney(){
		var payumoney= $('#payumoney').val();
		$.ajax({
	                    url: '<?php echo site_url('website/get_payu_order'); ?>',
	                    type: "POST",
	                    data: {
	                        'payumoney': payumoney
	                    },
	                    
	                    
	                    success: function (data) {
	                    if(data=='2'){
	                    		alert("Delivery Address is Empty");
	                    		$('#payumoney').attr('checked', false);
	                    	}else if(data=='1'){
	                    		payuForm.submit();
	                    		//$('#payumoney').attr('checked', false);
	                    	}else if(data=='3'){
	                    		alert("Your Cart is Empty, Please Continue Shopping");
	                    		
	                    		
	                    	}
	                    	 }
	                });
	}
	
$('#amount').val(localStorage.getItem('ttlcharges'));
	</script>