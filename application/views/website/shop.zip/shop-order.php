
            <!-- /.page-header -->
            <section class="section-full">
                <div class="container">
                    <ul class="shop-order-progress flex flex-center fw300 mb-50 fz-13">
                        <li class="active"><a href="#">Order</a></li>    
                        <li><a href="#">Shipping</a></li>    
                        <li><a href="#">Payment</a></li>    
                        <li><a href="#">Confirmation</a></li>    
                    </ul> <!-- end .order-progress -->

                    <div class="table-responsive">
                        <table class="table-1 table-cart w100">
                            <thead>
                                <tr class="fw300">
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total Price</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="cart_row">
                               
                            </tbody>
                        </table> <!-- /.table-1 -->
                    </div> <!-- end .table-responsive -->

                    <div class="row mt-50">
                        <div class="col-xs-12 col-md-4 bottom-margin">
                            <h5 class="roboto-slab text-uppercase fz-14 mb-30">Coupon Code</h4>
                            <form action="#" class="promo-code flex flex-middle">
                                <div class="input-field margin-b-0 w100">
                                    <input id="product_promo" required="" class="ml-input margin-b-0" type="text">
                                    <label for="product_promo" class="">Promo Code</label>
                                </div>
                                <button type="submit" class="btn btn-primary ml-15">Apply Promo</button>
                            </form>
                        </div> <!-- end .col-md-4 -->
                        <div class="col-xs-12 col-md-4 bottom-margin">
                            <h5 class="roboto-slab text-uppercase fz-14 mb-30">Estimated Shipping Tax</h4>
                            <div class="shipping_tax_box">
                            <div class="input-field margin-b-0 w100">
                                    <input id="postal_promo" required="" class="ml-input margin-b-0" type="text">
                                    <label for="postal_promo" class="">Postal Code</label>
                                </div>
                            </div>
                        </div> <!-- end .col-md-4 -->
                        <div class="col-xs-12 col-md-4 bottom-margin">
                            <div class="cart-subtotal fw300">
                                <p class="text-dark-54 flex space-between mb-15">
                                    <span class="text-dark fw300">Sub Total</span>
                                    <span class="oswald text-dark" id="subt"></span>
                                </p>
<!--                                <p class="text-dark-54 flex space-between mb-10">
                                    <span class="text-dark fw300">Discount (20%)</span>
                                    <span class="oswald danger">- </span>
                                </p>-->
                                <hr class="mb-15">
                                <p class="mb-10 text-dark fw300">Shipping Charge</p>
                                <div class="shipping-method flex flex-middle space-between mb-5">
                                    <label for="flat_rate" class="fw300">Flat Rate</label>
                                    <div class="custom-radio right" id="ship">
                                        
                                    </div>
                                </div>
                                <hr>
                                <p class="text-dark-54 flex flex-middle space-between mb-15">
                                    <span>Total</span>
                                    <span class="oswald h4 text-dark" id="ttlcharges"></span>
                                </p>
                            </div>
                        </div> <!-- end .col-md-4 -->
                        <div class="col-xs-12 text-right mt-100 cart-actions">
                            <a href="<?php echo site_url(); ?>/website" class="waves-effect btn-large btn-white text-uppercase">Continue Shoppning</a>
                            <a href="<?php echo site_url(); ?>/website/shipping" class="waves-effect btn-large waves-light btn-light-dark text-uppercase ml-20">Proceed to Checkout</a>
                        </div>
                    </div> <!-- end .row -->
                </div> <!-- /.container -->
            </section>
            <!-- //.section-full -->
            <script>
  $(document).ready(function() {
var subt=0;
var ship=0;
var quanty1=0;
var ttlcharges=0;
        for(var i=0;i<cart.length;i++){
$('#cart_row').append('<tr id="1'+i+'"><td><div class="flex mcart-product"><figure class="thumb mr-20 radius"><img src="'+cart[i].img+'" width="100" height="100" alt=""></figure><div class="desc"><h5 class="mb-10 fz-14"><a href="#" class="title-color">'+cart[i].name+'</a></h5><span class="fw300">Size : Large</span></div></div></td><td class="product-price"><span class="price title-color">'+cart[i].price+'</span></td><td class="product-quantity"><div class="quantity cart"><span class="quantity-field"> <button type="button" id="add" class="add"> <i class="fa fa-caret-up"></i> </button> <input type="number" onchange="changeByValue('+i+');" id="qtyp'+i+'" value="'+cart[i].qty+'" class="field"><button type="button" id="sub" class="sub"><i class="fa fa-caret-down"></i></button> </span></div></td><td class="product-price"><span class="price title-color">'+(cart[i].price*cart[i].qty)+'</span></td> <td class="remove-product"> <a href="javascript:;" class=""><svg version="1.1"  onclick="removeByValue('+i+');" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve"><polygon points="32.1,18.6 31.4,17.9 25,24.3 18.6,17.9 17.9,18.6 24.3,25 17.9,31.4 18.6,32.1 25,25.7 31.4,32.1 32.1,31.4 25.7,25 "></polygon><path d="M25,1c13.2,0,24,10.8,24,24S38.2,49,25,49S1,38.2,1,25S11.8,1,25,1 M25,0C11.2,0,0,11.2,0,25s11.2,25,25,25s25-11.2,25-25 S38.8,0,25,0L25,0z"></path></svg></a></td></tr>'); 
subt=subt+(cart[i].price*cart[i].qty);
  quanty1=parseInt(quanty1)+parseInt(cart[i].qty);
  //alert(quanty1);
    }
    ship=(quanty1*10)+10;
  localStorage.setItem('subt', subt);
   localStorage.setItem('quanty1', quanty1);
   localStorage.setItem('ship', ship);
   ttlcharges=subt+ship;
  $('#subt').html('Rs '+subt);
  $('#ship').html('Rs '+ship);
  
  $('#ttlcharges').html('Rs '+ttlcharges);
  
});
</script>